//Write a C program to sort the elements of a queue in ascending order.
#include <stdio.h>
#include <stdlib.h>

// Structure for a Queue Node
struct Node {
    int data;
    struct Node* next;
};

// Structure for Queue
struct Queue {
    struct Node *front, *rear;
};

// Function to create a new Queue
struct Queue* createQueue() {
    struct Queue* q = (struct Queue*)malloc(sizeof(struct Queue));
    q->front = q->rear = NULL;
    return q;
}

// Function to enqueue an element
void enqueue(struct Queue* q, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;

    if (q->rear == NULL) {
        q->front = q->rear = newNode;
        return;
    }

    q->rear->next = newNode;
    q->rear = newNode;
}

// Function to display the queue
void displayQueue(struct Queue* q) {
    struct Node* temp = q->front;
    while (temp) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
}

// Function to sort the queue in ascending order
void sortQueue(struct Queue* q) {
    if (q->front == NULL) return;

    struct Node *i, *j;
    int temp;

    // Bubble Sort on linked list queue
    for (i = q->front; i != NULL; i = i->next) {
        for (j = i->next; j != NULL; j = j->next) {
            if (i->data > j->data) {
                temp = i->data;
                i->data = j->data;
                j->data = temp;
            }
        }
    }
}

int main() {
    struct Queue* q = createQueue();

    // Enqueueing some elements
    enqueue(q, 4);
    enqueue(q, 2);
    enqueue(q, 7);
    enqueue(q, 5);
    enqueue(q, 1);

    printf("Original Queue: ");
    displayQueue(q);

    // Sorting the queue
    sortQueue(q);

    printf("Sorted Queue in Ascending Order: ");
    displayQueue(q);

    return 0;
}
