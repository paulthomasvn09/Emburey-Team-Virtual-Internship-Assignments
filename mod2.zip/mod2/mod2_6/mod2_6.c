//Insert value in sorted way in a sorted doubly linked list. Given a sorted doubly linked list and a value to insert, write a function to insert the value in sorted way.
#include <stdio.h>
#include <stdlib.h>

// Node structure for Doubly Linked List
struct Node {
    int data;
    struct Node* prev;
    struct Node* next;
};

// Function to create a new node
struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->prev = newNode->next = NULL;
    return newNode;
}

// Function to insert in sorted order
void insertInSortedOrder(struct Node** head, int value) {
    struct Node* newNode = createNode(value);

    // If list is empty
    if (*head == NULL) {
        *head = newNode;
        return;
    }

    struct Node* current = *head;

    // Insert at the beginning
    if (value <= current->data) {
        newNode->next = current;
        current->prev = newNode;
        *head = newNode;
        return;
    }

    // Traverse to find the position
    while (current->next && current->next->data < value) {
        current = current->next;
    }

    // Insert at the end
    if (current->next == NULL) {
        current->next = newNode;
        newNode->prev = current;
        return;
    }

    // Insert in the middle
    newNode->next = current->next;
    newNode->prev = current;
    current->next->prev = newNode;
    current->next = newNode;
}

// Function to print the list
void printList(struct Node* head) {
    struct Node* temp = head;
    while (temp) {
        printf("%d <-> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

int main() {
    struct Node* head = NULL;

    // Creating a sorted doubly linked list
    insertInSortedOrder(&head, 3);
    insertInSortedOrder(&head, 5);
    insertInSortedOrder(&head, 8);
    insertInSortedOrder(&head, 10);
    insertInSortedOrder(&head, 12);

    printf("Initial Sorted Doubly Linked List: \n");
    printList(head);

    // Inserting new value in sorted order
    insertInSortedOrder(&head, 9);

    printf("\nDoubly Linked List after insertion of 9:\n");
    printList(head);

    return 0;
}
