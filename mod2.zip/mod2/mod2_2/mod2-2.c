//Write a C program to rotate a doubly linked list by N nodes.
#include <stdio.h>
#include <stdlib.h>

// Structure for a doubly linked list node
struct Node {
    char data;
    struct Node* prev;
    struct Node* next;
};

// Function to create a new node
struct Node* createNode(char data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->prev = newNode->next = NULL;
    return newNode;
}

// Function to append a node to the end
void append(struct Node** head, char data) {
    struct Node* newNode = createNode(data);
    if (*head == NULL) {
        *head = newNode;
        return;
    }

    struct Node* temp = *head;
    while (temp->next)
        temp = temp->next;

    temp->next = newNode;
    newNode->prev = temp;
}

// Function to rotate doubly linked list left by N nodes
void rotateLeft(struct Node** head, int N) {
    if (*head == NULL || N == 0)
        return;

    struct Node* current = *head;
    int count = 1;

    // Traverse to the Nth node
    while (count < N && current) {
        current = current->next;
        count++;
    }

    // If N is greater than the list length
    if (current == NULL) return;

    // New head will be (N+1)th node
    struct Node* newHead = current->next;

    if (newHead == NULL) return; // No rotation needed

    newHead->prev = NULL;
    current->next = NULL;

    // Traverse to the end of the list
    struct Node* temp = newHead;
    while (temp->next)
        temp = temp->next;

    // Connect end to the old head
    temp->next = *head;
    (*head)->prev = temp;

    // Update head
    *head = newHead;
}

// Function to print the list
void printList(struct Node* head) {
    while (head) {
        printf("%c <-> ", head->data);
        head = head->next;
    }
}

int main() {
    struct Node* head = NULL;
     int N ; // Rotate by N nodes
    scanf("%d",&N);
    
    // Creating a doubly linked list
    append(&head, 'a');
    append(&head, 'b');
    append(&head, 'c');
    append(&head, 'd');
    append(&head, 'e');

    printf("Original List: ");
    printList(head);
    rotateLeft(&head, N);
    printList(head);

    printf("After Rotating Left by %d nodes: ", N);
    printList(head);

    return 0;
}
