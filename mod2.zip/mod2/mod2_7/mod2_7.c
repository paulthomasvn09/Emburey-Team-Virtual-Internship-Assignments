//Write a C program to insert/delete and count the number of elements in a queue.
#include <stdio.h>
#include <stdlib.h>

// Queue Node structure
struct Node {
    int data;
    struct Node* next;
};

// Queue structure with front, rear, and size
struct Queue {
    struct Node* front;
    struct Node* rear;
    int size;
};

// Function to initialize a queue
struct Queue* initializeQueue() {
    struct Queue* q = (struct Queue*)malloc(sizeof(struct Queue));
    q->front = q->rear = NULL;
    q->size = 0;
    return q;
}

// Function to check if the queue is empty
int isEmpty(struct Queue* q) {
    return (q->size == 0);
}

// Function to insert an element into the queue
void enqueue(struct Queue* q, int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = NULL;

    if (q->rear == NULL) {
        q->front = q->rear = newNode;
    } else {
        q->rear->next = newNode;
        q->rear = newNode;
    }

    q->size++;
}

// Function to delete an element from the queue
void dequeue(struct Queue* q) {
    if (isEmpty(q)) {
        printf("Queue is empty.\n");
        return;
    }

    struct Node* temp = q->front;
    q->front = q->front->next;

    if (q->front == NULL)
        q->rear = NULL;

    free(temp);
    q->size--;
}

// Function to display the queue elements
void displayQueue(struct Queue* q) {
    struct Node* temp = q->front;
    if (isEmpty(q)) {
        printf("Queue is empty.\n");
        return;
    }

    while (temp) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

// Main function
int main() {
    struct Queue* q = initializeQueue();

    printf("Initialize a queue!\n");

    printf("Check the queue is empty or not? %s\n", isEmpty(q) ? "Yes" : "No");
    printf("Number of elements in queue: %d\n\n", q->size);

    // Inserting elements
    printf("Insert some elements into the queue:\n");
    enqueue(q, 1);
    enqueue(q, 2);
    enqueue(q, 3);

    printf("Queue elements are: ");
    displayQueue(q);
    printf("Number of elements in queue: %d\n\n", q->size);

    // Deleting two elements
    printf("Delete two elements from the said queue:\n");
    dequeue(q);
    dequeue(q);

    printf("Queue elements are: ");
    displayQueue(q);
    printf("Number of elements in queue: %d\n\n", q->size);

    // Inserting another element
    printf("Insert another element into the queue:\n");
    enqueue(q, 4);

    printf("Queue elements are: ");
    displayQueue(q);
    printf("Number of elements in the queue: %d\n", q->size);

    return 0;
}
