//Reverse the given string using stack.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure for Stack
struct Stack {
    int top;
    unsigned capacity;
    char* array;
};

// Function to create a stack
struct Stack* createStack(unsigned capacity) {
    struct Stack* stack = (struct Stack*)malloc(sizeof(struct Stack));
    stack->capacity = capacity;
    stack->top = -1;
    stack->array = (char*)malloc(stack->capacity * sizeof(char));
    return stack;
}

// Function to check if the stack is empty
int isEmpty(struct Stack* stack) {
    return stack->top == -1;
}

// Function to push an element onto the stack
void push(struct Stack* stack, char item) {
    stack->array[++stack->top] = item;
}

// Function to pop an element from the stack
char pop(struct Stack* stack) {
    if (!isEmpty(stack))
        return stack->array[stack->top--];
    return '\0'; // Return null character if stack is empty
}

// Function to reverse a string using stack
void reverseString(char str[]) {
    int n = strlen(str);
    struct Stack* stack = createStack(n);
    for (int i = 0; i < n; i++)
        push(stack, str[i]);
    for (int i = 0; i < n; i++)
        str[i] = pop(stack);

    free(stack->array);
    free(stack);
}

int main() {
    char str[100];
    printf("Enter a string: ");
    scanf("%s", str);

    reverseString(str);

    printf("Reversed String: %s\n", str);

    return 0;
}
