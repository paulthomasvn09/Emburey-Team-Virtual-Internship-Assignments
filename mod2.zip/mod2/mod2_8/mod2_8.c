//Write a C program to Find whether an array is a subset of another array. 
#include <stdio.h>
#include <stdlib.h>
// Function to check if arr2 is a subset of arr1
int isSubset(int arr1[], int size1, int arr2[], int size2) {
    int *hashTable = (int *)calloc(100000, sizeof(int)); // Hash table for counting

    // Insert all elements of arr1 into hash table
    for (int i = 0; i < size1; i++) {
        hashTable[arr1[i]] = 1;
    }

    // Check if all elements of arr2 are in hash table
    for (int i = 0; i < size2; i++) {
        if (hashTable[arr2[i]] == 0) {
            free(hashTable);
            return 0; // If any element is not found
        }
    }

    free(hashTable);
    return 1; // All elements found
}

int main() {
    int arr1[] = {11, 1, 13, 21, 3, 7};
    int arr2[] = {11, 3, 7, 1};

    int size1 = sizeof(arr1) / sizeof(arr1[0]);
    int size2 = sizeof(arr2) / sizeof(arr2[0]);

    if (isSubset(arr1, size1, arr2, size2))
        printf("arr2[] is a subset of arr1[]\n");
    else
        printf("arr2[] is not a subset of arr1[]\n");


    return 0;
}
