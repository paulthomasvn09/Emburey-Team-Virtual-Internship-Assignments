//Write a C program to remove duplicate element from sorted Linked List. 

#include <stdio.h>
#include <stdlib.h>

// Definition of the Linked List Node
struct Node {
    int data;
    struct Node *next;
};

// Function to create a new Node
struct Node *createNode(int data) {
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// Function to insert a Node at the end of the Linked List
void insertAtEnd(struct Node **head, int data) {
    struct Node *newNode = createNode(data);
    if (*head == NULL) {
        *head = newNode;
        return;
    }

    struct Node *temp = *head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newNode;
}

// Function to remove duplicate elements from a sorted Linked List
void removeDuplicates(struct Node *head) {
    struct Node *current = head;
    struct Node *nextNode;

    while (current != NULL && current->next != NULL) {
        if (current->data == current->next->data) {
            nextNode = current->next;
            current->next = current->next->next;
            free(nextNode);
        } else {
            current = current->next;
        }
    }
}

// Function to display the Linked List
void displayList(struct Node *head) {
    struct Node *temp = head;
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    
}
void sortList(struct Node *head) {
    if (head == NULL) return;
    
    struct Node *i, *j;
    int tempData;

    for (i = head; i->next != NULL; i = i->next) {
        for (j = i->next; j != NULL; j = j->next) {
            if (i->data > j->data) {
                tempData = i->data;
                i->data = j->data;
                j->data = tempData;
            }
        }
    }
}
// Main function
int main() {
    struct Node *head = NULL;
    // Creating a sorted linked list with duplicate elements
    int num,n;
    printf("Number of elements:");
    scanf("%d",&n);
    for(int k=0; k<n; k++){
	 scanf("%d", &num);
   	 insertAtEnd(&head, num);
}
    printf("Original Linked List:\n");
    displayList(head);
    sortList(head);
	 // Removing duplicates
    removeDuplicates(head);

    printf("\nLinked List after removing duplicates:\n");
    displayList(head);

    return 0;
}

