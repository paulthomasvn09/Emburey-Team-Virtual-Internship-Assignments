// Write a C program to demonstrate the use of Mutexes in threads synchronization  Explain

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

// Mutex variable
pthread_mutex_t lock; // Global mutex lock
int shared_counter = 0; // Shared resource

void *increment(void *arg) {
    for (int i = 0; i < 1000000; i++) {
        pthread_mutex_lock(&lock); 
        shared_counter++;          
        pthread_mutex_unlock(&lock); // Unlocking the mutex
    }
    return NULL;
}

int main() {
    pthread_t t1, t2; 
     // Initializing mutex
    pthread_mutex_init(&lock, NULL);
    pthread_create(&t1, NULL, increment, NULL);
    pthread_create(&t2, NULL, increment, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_mutex_destroy(&lock);
    printf("Final value of shared counter: %d\n", shared_counter);
    return 0;
}
