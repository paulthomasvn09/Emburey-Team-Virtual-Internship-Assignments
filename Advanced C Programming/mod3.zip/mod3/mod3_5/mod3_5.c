// Create two thread functions to print hello and world separately and create threads for each and execute them one after other in C

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void *print_hello(void *arg) {
    printf("Hello ");
    pthread_exit(NULL);
}
void *print_world(void *arg) {
    printf("World\n");
    pthread_exit(NULL);
}

int main() {
    pthread_t thread1, thread2;
    pthread_create(&thread1, NULL, print_hello, NULL);
    pthread_join(thread1, NULL);
    pthread_create(&thread2, NULL, print_world, NULL);
    pthread_join(thread2, NULL);
    return 0;
}
