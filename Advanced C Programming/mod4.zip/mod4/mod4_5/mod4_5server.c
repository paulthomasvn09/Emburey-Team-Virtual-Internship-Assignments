//Write a TCP server-client program to check if a given string is Palindrome

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

// Function to check if a string is palindrome
int is_palindrome(char *str) {
    int len = strlen(str);
    for (int i = 0; i < len / 2; i++) {
        if (str[i] != str[len - i - 1])
            return 0; // Not a palindrome
    }
    return 1; // Palindrome
}

int main() {
    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    char buffer[BUFFER_SIZE];

    // 1. Create socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("Socket creation failed");
        return -1;
    }

    // 2. Setup server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // 3. Bind socket
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        return -1;
    }

    // 4. Listen for connections
    listen(server_fd, 5);
    printf("Server listening on port %d...\n", PORT);

    // 5. Accept client connection
    socklen_t addr_len = sizeof(client_addr);
    client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addr_len);

    // 6. Receive string from client
    read(client_fd, buffer, BUFFER_SIZE);
    printf("Client: %s\n", buffer);

    // 7. Check if it is a palindrome
    char response[BUFFER_SIZE];
    if (is_palindrome(buffer))
        strcpy(response, "Palindrome");
    else
        strcpy(response, "Not a Palindrome");

    // 8. Send response
    write(client_fd, response, strlen(response));

    // 9. Close connection
    close(client_fd);
    close(server_fd);

    return 0;
}
