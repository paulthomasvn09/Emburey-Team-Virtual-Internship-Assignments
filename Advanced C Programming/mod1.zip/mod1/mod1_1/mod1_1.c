//Write a C program to determine the given number is odd or even using Bitwise operators. 


#include <stdio.h>

int main() {
    int num;
    printf("Enter an integer: ");
    scanf("%d", &num);
    if (num & 1)    //Check if last bit is 1 or 0.
        printf("%d is an Odd number.\n", num);
    else
        printf("%d is an Even number.\n", num);

    return 0;
}

