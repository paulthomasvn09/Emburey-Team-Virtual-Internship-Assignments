//Write a C program to swap two numbers. Use a function pointer to do this operation.

#include <stdio.h>

// Function to swap two numbers
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main() {
    int num1, num2;
    printf("Enter two numbers: ");
    scanf("%d, %d", &num1, &num2);
    printf("num1 = %d, num2 = %d\n", num1, num2);
    // Declaring a function pointer for swap
    void (*swapPtr)(int *, int *) = swap;
    // Swapping using function pointer
    swapPtr(&num1, &num2);
    // Displaying swapped values
    printf("num1 = %d, num2 = %d\n", num1, num2);
    return 0;
}

