//Write a C program to count the number of bits set in a number.

#include <stdio.h>

int setbit(unsigned int n){
	int count =0;
	while(n){
		n&=(n-1);
		count++;
		}
	return count;
}
int main(){
	unsigned int num;
	printf("Enter the number: ");
	scanf("%u", &num);
	int set = setbit(num);
	printf("The number of bits set in number %u is %d", num, set);
	return 0;
}
